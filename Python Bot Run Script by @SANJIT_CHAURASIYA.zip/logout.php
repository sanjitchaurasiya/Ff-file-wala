<?php
// © 2025 Developed by t.me/SANJIT_CHAURASIYA
//Do not Sell This Code 
session_start();
session_destroy();
header("Location: login.php");
exit;